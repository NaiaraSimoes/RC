#!/usr/bin/env python3

 

import rospy
from geometry_msgs.msg import PoseStamped
 
def send_goal(x, y, yaw):
    # Configurações do frame de referência e goal
    goal = PoseStamped()
    goal.header.frame_id = "map"  # Frame de referência
    goal.header.stamp = rospy.Time.now()

    # Definir posição (x, y)
    goal.pose.position.x = x
    goal.pose.position.y = y
    goal.pose.position.z = 0.0

    # Definir orientação (em quaternion)
    from tf.transformations import quaternion_from_euler
    q = quaternion_from_euler(0, 0, yaw)  # Roll, Pitch, Yaw
    goal.pose.orientation.x = q[0]
    goal.pose.orientation.y = q[1]
    goal.pose.orientation.z = q[2]
    goal.pose.orientation.w = q[3]

    # Publicar o goal
    pub.publish(goal)
    rospy.loginfo(f"Goal enviado para x: {x}, y: {y}, yaw: {yaw}")

if __name__ == "__main__":
    rospy.init_node("navigation_goals", anonymous=True)

    # Publicador para o tópico do move_base
    pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)

    rospy.sleep(1)  # Aguarda conexão com o tópico

    # Coordenadas: (x, y, yaw) para a cozinha e despensa
    cozinha = (-2.424, 2.198, 0)  # Substituir pelas coordenadas reais da cozinha
    despensa = (1.721, 4.370, 0)  # Substituir pelas coordenadas reais da despensa

    rospy.loginfo("Indo para a despensa...")
    send_goal(*despensa)  # Enviar o goal para a despensa

    rospy.sleep(20)  # Tempo estimado para o robô chegar

    rospy.loginfo("Voltando para a cozinha...")
    send_goal(*cozinha)  # Enviar o goal para a cozinha

    rospy.sleep(20)  # Tempo estimado para o robô chegar
