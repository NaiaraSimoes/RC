#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import PoseStamped
from tf.transformations import quaternion_from_euler

def send_goal(x, y, yaw):
    goal = PoseStamped()
    goal.header.frame_id = "map"
    goal.header.stamp = rospy.Time.now()
    goal.pose.position.x = x
    goal.pose.position.y = y
    goal.pose.position.z = 0.0

    q = quaternion_from_euler(0, 0, yaw)
    goal.pose.orientation.x = q[0]
    goal.pose.orientation.y = q[1]
    goal.pose.orientation.z = q[2]
    goal.pose.orientation.w = q[3]

    pub.publish(goal)
    rospy.loginfo(f"Goal enviado: x={x}, y={y}, yaw={yaw}")

if __name__ == "__main__":
    rospy.init_node("servico_ou_despensa", anonymous=True)
    pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
    rospy.sleep(1)  # Aguarda a conexão com o tópico

    cozinha = (-2.424, 2.198, 0) 
    despensa = (0.672, 3.94, 0)  # Coordenadas da despensa
    quartos = {
        "quarto1": (6.144, -2.578, 0),
        "quarto2": (2.769, -2.846, 0),
        "quarto3": (-1.915, -2.217, 0)
    }

    try:
        while not rospy.is_shutdown():
            print("\nEscolha uma opção:")
            print("1. Ir para a despensa")
            print("2. Ir para o serviço de quartos")
            print("3. Sair")
            escolha = input("Digite sua escolha (1/2/3): ")

            if escolha == "1":
                rospy.loginfo("Indo para a despensa...")
                send_goal(*despensa)
                rospy.sleep(20)  # Aguarda para o robô alcançar o objetivo

            elif escolha == "2":
                rospy.loginfo("Quartos disponíveis: " + ", ".join(quartos.keys()))
                quarto_escolhido = input("Escolha um quarto (quarto1, quarto2, quarto3): ").strip()

                if quarto_escolhido in quartos:
                    rospy.loginfo(f"Indo para o {quarto_escolhido}...")
                    send_goal(*quartos[quarto_escolhido])  # Enviar o goal
                    rospy.sleep(30)  # Tempo estimado para o robô chegar

                rospy.loginfo("Voltando para a cozinha...")
                send_goal(*cozinha)  # Voltar para a cozinha

                rospy.sleep(30)  # Tempo estimado para o robô chegar

            elif escolha == "3":
                rospy.loginfo("Encerrando...")
                break

            else:
                print("Escolha inválida. Tente novamente.")

    except rospy.ROSInterruptException:
        rospy.loginfo("Nó encerrado.")
